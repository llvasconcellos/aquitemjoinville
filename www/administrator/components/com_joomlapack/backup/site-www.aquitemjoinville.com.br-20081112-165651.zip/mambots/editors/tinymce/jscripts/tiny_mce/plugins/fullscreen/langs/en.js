// PT_BR lang variables / pt-BR = Portugues (Brasil)
/**
 * Authors : Lena - www.facilhost.com.br
 * Last Updated : 27-07-2007
 */

tinyMCE.addToLang('',{
fullscreen_title : 'Visualiar tela completa',
fullscreen_desc : 'Alterar para Modo de exibi��o de tela completa'
});
