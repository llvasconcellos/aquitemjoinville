// PT_BR lang variables / pt-BR = Portugues (Brasil)
/**
 * Authors : Lena - www.facilhost.com.br
 * Last Updated : 27-07-2007
 */

tinyMCE.addToLang('nonbreaking',{
desc : 'Inserir Espa�o Inquebr�vel'
});
