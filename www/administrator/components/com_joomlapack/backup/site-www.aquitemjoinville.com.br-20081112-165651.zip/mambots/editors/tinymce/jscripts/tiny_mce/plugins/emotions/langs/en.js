// PT_BR lang variables / pt-BR = Portugues (Brasil)
/**
 * Authors : Lena - www.facilhost.com.br <www.biblioteia.com>
 * Last Updated : 27-07-2007
 */
tinyMCE.addToLang('emotions',{
title : 'Inserir emo��o',
desc : 'Emo��es',
cool : 'Descontra�do',
cry : 'Chorar',
embarassed : 'Envergonhado',
foot_in_mouth : 'Asneira',
frown : 'Triste',
innocent : 'Inocente',
kiss : 'Beijo',
laughing : 'Gargalhada',
money_mouth : 'Interesseiro',
sealed : 'Calado',
smile : 'Sorriso',
surprised : 'Surpreendido',
tongue_out : 'L�ngua_de_fora',
undecided : 'Indeciso',
wink : 'Piscadela',
yell : 'Gritar'
});
