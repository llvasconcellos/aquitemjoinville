// PT_BR lang variables / pt-BR = Portugues (Brasil)
/**
 * Authors : Lena - www.facilhost.com.br <www.biblioteia.com>
 * Last Updated : 27-07-2007
 */

tinyMCE.addToLang('',{
autosave_unload_msg : 'AS modifica��es que efetuou ser�o perdidas se sair desta p�gina sem antes salvar.'
});
