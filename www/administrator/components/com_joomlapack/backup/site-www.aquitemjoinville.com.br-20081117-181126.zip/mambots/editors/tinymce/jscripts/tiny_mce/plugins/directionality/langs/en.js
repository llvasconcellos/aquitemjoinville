// PT_BR lang variables / pt-BR = Portugues (Brasil)
/**
 * Authors : Lena - www.facilhost.com.br <www.biblioteia.com>
 * Last Updated : 27-07-2007
 */

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Dire��o da esquerda para a direita',
directionality_rtl_desc : 'Dire��o da direita para a esquerda'
});
