// PT_BR lang variables / pt-BR = Portugues (Brasil)
/**
 * Authors : Lena - www.facilhost.com.br <www.biblioteia.com>
 * Last Updated : 27-07-2007
 */

/* Remember to namespace the language parameters lang_<your plugin>_<some name> */

tinyMCE.addToLang('',{
template_title : 'Um bot�o pop-up',
template_desc : 'Um bot�o para tema'
});
