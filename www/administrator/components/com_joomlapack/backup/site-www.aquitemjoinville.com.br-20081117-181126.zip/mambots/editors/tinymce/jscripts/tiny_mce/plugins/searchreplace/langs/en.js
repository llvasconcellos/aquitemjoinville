// PT_BR lang variables / pt-BR = Portugues (Brasil)
/**
 * Authors : Lena - www.facilhost.com.br
 * Last Updated : 27-07-2007
 */

tinyMCE.addToLang('',{
searchreplace_search_desc : 'Procurar',
searchreplace_searchnext_desc : 'Procurar novamente',
searchreplace_replace_desc : 'Procurar/Substituir',
searchreplace_notfound : 'Pesquisa conclu�da. A express�o pesquisada n�o foi encontrada.',
searchreplace_search_title : 'Procurar',
searchreplace_replace_title : 'Procurar/Substituir',
searchreplace_allreplaced : 'Todas as ocorr�ncias da express�o pesquisada foram substitu�das.',
searchreplace_findwhat : 'Procurar por',
searchreplace_replacewith : 'Substituir por',
searchreplace_direction : 'Dire��o',
searchreplace_up : 'Para cima',
searchreplace_down : 'Para baixo',
searchreplace_case : 'Pesquisa Exacta',
searchreplace_findnext : 'Encontrar&nbsp;seguinte',
searchreplace_replace : 'Substituir',
searchreplace_replaceall : 'Substituir&nbsp;todas',
searchreplace_cancel : 'Cancelar'
});
