// PT_BR lang variables / pt-BR = Portugues (Brasil)
/**
 * Authors : Lena - www.facilhost.com.br <www.biblioteia.com>
 * Last Updated : 27-07-2007
 */

tinyMCE.addToLang('',{
insert_advhr_desc : 'Inserir/editar Linha Horizontal',
insert_advhr_width : 'Largura',
insert_advhr_size : 'Altura',
insert_advhr_noshade : 'Sem Sombra'
});
