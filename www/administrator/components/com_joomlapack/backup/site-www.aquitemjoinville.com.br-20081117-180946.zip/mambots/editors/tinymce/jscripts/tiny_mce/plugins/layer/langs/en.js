// PT_BR lang variables / pt-BR = Portugues (Brasil)
/**
 * Authors : Lena - www.facilhost.com.br
 * Last Updated : 27-07-2007
 */

tinyMCE.addToLang('layer',{
insertlayer_desc : 'Inserir nova camada',
forward_desc : 'Avan�ar',
backward_desc : 'Retornar',
absolute_desc : 'Ativar posicionamento absoluto',
content : 'Nova camada...'
});
