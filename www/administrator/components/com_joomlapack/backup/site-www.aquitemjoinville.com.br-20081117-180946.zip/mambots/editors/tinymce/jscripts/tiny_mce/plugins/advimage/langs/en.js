// PT_BR lang variables / pt-BR = Portugues (Brasil)
/**
 * Authors : Lena - www.facilhost.com.br <www.biblioteia.com>
 * Last Updated : 27-07-2007
 */

tinyMCE.addToLang('advimage',{
tab_general : 'Geral',
tab_appearance : 'Aspecto',
tab_advanced : 'Avan�ado',
general : 'Geral',
title : 'T�tulo',
preview : 'Pr�-visualizar',
constrain_proportions : 'Manter propor��es',
langdir : 'Dire��o da Escrita',
langcode : 'C�digo do idioma',
long_desc : 'Descri��o longa do link',
style : 'Estilo',
classes : 'Classes',
ltr : 'Esquerda para a direita',
rtl : 'Direita para a esquerda',
id : 'Id',
image_map : 'Imagem mapa',
swap_image : 'Trocar imagem',
alt_image : 'Imagem Alternativa',
mouseover : 'quando mouse passar por cima',
mouseout : 'depois de sa�da do mouse',
misc : 'Diversos',
example_img : 'Aspecto&nbsp;pr�-visualiza��o&nbsp;imagem',
missing_alt : 'Tem a certeza que pretende continuar sem incluir uma descri��o da imagem? Lembre-se que a imagem poder� n�o estar dispon�vel para alguns utilizadores com incapacidades, para os que utilizem um navegador texto ou naveguem na Web com as imagens desligadas.'
});
