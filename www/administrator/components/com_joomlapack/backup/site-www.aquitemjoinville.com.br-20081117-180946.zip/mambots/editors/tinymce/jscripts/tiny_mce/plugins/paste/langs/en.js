// PT_BR lang variables / pt-BR = Portugues (Brasil)
/**
 * Authors : Lena - www.facilhost.com.br
 * Last Updated : 27-07-2007
 */

tinyMCE.addToLang('',{
paste_text_desc : 'Colar como texto simples',
paste_text_title : 'Utilize CTRL+V no teclado para colar o texto na janela.',
paste_text_linebreaks : 'Manter quebras de linha',
paste_word_desc : 'Colar a partir de processador de texto',
paste_word_title : 'Utilizar CTRL+V no teclado para colar o texto na janela.',
selectall_desc : 'Selecionar tudo'
});
