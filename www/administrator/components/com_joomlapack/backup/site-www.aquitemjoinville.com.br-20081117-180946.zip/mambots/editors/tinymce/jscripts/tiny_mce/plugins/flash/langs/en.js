// PT_BR lang variables / pt-BR = Portugues (Brasil)
/**
 * Authors : Lena - www.facilhost.com.br <www.biblioteia.com>
 * Last Updated : 27-07-2007
 */

tinyMCE.addToLang('flash',{
title : 'Inserir / editar arquivo Flash',
desc : 'Inserir / editar arquivo Flash',
file : 'Arquivo Flash (.swf)',
size : 'Tamanho',
list : 'Lista de arquivo Flash',
props : 'Propriedades do Flash',
general : 'Geral'
});
